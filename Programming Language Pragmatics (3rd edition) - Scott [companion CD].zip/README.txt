
Using this Download

Welcome to the Programming Language Pragmatics, 3rd Edition Companion CD content.
This page contains some information to help you get started.

    * What you will find in the download
    * System Requirements
    * Locating content
          o Page, Figure and Exercise numbering
    * Copying the CD content onto your hard drive
    * Acknowledgments

--------------------------------------------------------------------------------
What you will find
- In More Depth sections and sub-sections that are introduced in the book
- In More Depth Exercises and Explorations for students wanting additional challenges
- Links to Web-based language reference manuals, tutorials, compilers and interpreters
- Text files containing the code fragments featured as examples in the book
--------------------------------------------------------------------------------

System Requirements

PDF Viewer
The CD material is a PDF based application that you can read with a PDF viewer such as Adobe� Acrobat�
or Adobe Reader�. The content is designed to be viewed in a browser window that is at least 720 pixels wide.
You may find the content does not display well if your display is not set to at least 1024x768 pixel resolution.
Click here to visit the Adobe Reader home page for more information on this software.

Operating System
This CD can be used under any operating system, including Windows, Mac OS, and Linux.

To get started, double-click the PDF file named:

"CD-ROM_Menu_Bonus_Content_and_Exercises"

...and follow the instructions below.

Searching For Content
The navigation sidebar contains buttons to access the content of this CD according to category. Since the
content of this CD is delivered in Adobe PDF (Portable Document Format), you can search within the
application using the search features of your PDF viewer. For more information on searching within a PDF file,
see the help menu within your PDF viewer. You may also use the CTRL+F feature as found in the edit drop down
menu. To search within the entire content of the CD, use the full search feature located under Edit in the tool
bar. Simply choose �Search All PDF Documents In�, then choose your CD Drive as the location. You may also
search this way using SHIFT+CTRL+F.

Page, Figure and Exercise Numbering
Pages in the printed book are numbered sequentially (1, 2, 3, and so on). Wherever you find a simple page
number or page range (for example, �page 203� or �134-145�) you will know that this reference refers to a
page or pages in the printed book.

CD-based pages are also numbered sequentially. However, they are distinguished from printed book page numbers by 
the inclusion of a CD icon that accompanies the page number. The CD page number sequence extends over all of the 
CD-only Sections, Exercises and Explorations material.

Figures and Examples
Figures and Examples in the printed book are numbered sequentially within each chapter:
- Figure 1.1, Figure 1.2, Figure 1.3, etc.
- Example 1.1, Example 1.2, Example 1.3, etc.
The CD-based content continues the sequence from where it left off in the printed book chapter. So, for
example, if the last figure in Chapter 2 of the printed book is Figure 2.32, the first figure in the CD-based
material for Chapter 2 will be Figure 2.33. Examples are treated in the same way.

Exercises and Explorations
Exercises and Explorations are also numbered sequentially within each chapter of the printed book, with
the sequence continuing on the CD, in a way similar to Figures and Examples.


------------------------------------------------------------------------

    Acknowledgments

    * This CD was developed by AdvanTech Media (www.advantechmedia.com).
    * "Adobe", "Acrobat", and "Reader" are trademarks or registered
      trademarks of Adobe Systems Incorporated in the United States
      and/or other countries. 
