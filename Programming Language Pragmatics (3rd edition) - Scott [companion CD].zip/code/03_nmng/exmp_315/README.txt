To the best of my knowledge, no Euclid compilers are available for
modern machines.  The code in Figure 3.8 has not been tested.
