The code in example 8.68 has not been tested.
