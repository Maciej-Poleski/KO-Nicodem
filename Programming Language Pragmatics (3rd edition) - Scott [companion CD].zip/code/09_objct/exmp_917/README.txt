Example 9.17: see code in example_9.08-11/gp_list.cc.
