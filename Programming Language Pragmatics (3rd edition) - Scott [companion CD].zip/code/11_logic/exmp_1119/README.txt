See extended (full-game-playing) version in example_11.29.
