Fleshing out the code of Example 6.69 is the task of Exercise 6.18.
