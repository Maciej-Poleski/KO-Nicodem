Fleshing out the code of Example 6.66 is the task of Exercise 6.17.
