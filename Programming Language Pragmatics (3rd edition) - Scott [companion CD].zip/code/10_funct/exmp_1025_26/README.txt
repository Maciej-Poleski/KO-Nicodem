Streams (Examples 10.25 and 10.26) don't work as shown in the book in
Scheme because Scheme uses applicative order evaluation.  They can be
made to work with delay and force; this is the subject of Exercise 10.12.
